package people;
/**
 * Enum with the possible States of a driver
 * @author juan
 *
 */
public enum StateDriver {
	offline,onDuty,onARide,offDuty
}