package ride;
/**
 * 
 * Enum with the different status of a ride
 * 
 * @author juan
 *
 */
public enum Status {
	UNCONFIRMED,CONFIRMED,ONGOING,COMPLETED,CANCELLED;
}
