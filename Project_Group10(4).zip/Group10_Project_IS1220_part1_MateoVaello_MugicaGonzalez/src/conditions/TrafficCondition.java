package conditions;
/**
 * Enum with the three traffic conditions
 * 
 * @author Juan
 *
 */
public enum TrafficCondition {
	 light,medium,heavy;
	}
